//
//  ProductData.swift
//  FarmersMarketProject
//
//  Created by Ариана Кенбаева on 20.11.2024.
//
import Foundation

class ProductData {
    func getProducts() -> [Product] {
        return [
            Product(
                name: "Fresh Strawberries",
                category: "Fruits",
                price: 2000,
                quantity: 100,
                farmLocation: "Green Fields",
                description: "Sweet and organic strawberries"
            ),
            Product(
                name: "Fresh Strawberries",
                category: "Fruits",
                price: 2500,
                quantity: 80,
                farmLocation: "Berry Farm",
                description: "Ripe strawberries picked at peak freshness"
            ),
            Product(
                name: "Organic Kale",
                category: "Vegetables",
                price: 3000,
                quantity: 50,
                farmLocation: "Green Fields",
                description: "Healthy and fresh kale, grown without pesticides"
            ),
            Product(
                name: "Organic Kale",
                category: "Vegetables",
                price: 2900,
                quantity: 60,
                farmLocation: "Healthy Harvest",
                description: "Crisp and vibrant organic kale"
            ),
            Product(
                name: "Yellow Corn",
                category: "Vegetables",
                price: 1500,
                quantity: 300,
                farmLocation: "Sunny Acres",
                description: "Sweet yellow corn, perfect for summer BBQs"
            ),
            Product(
                name: "Yellow Corn",
                category: "Vegetables",
                price: 1000,
                quantity: 250,
                farmLocation: "Corn Valley",
                description: "Juicy and fresh yellow corn"
            ),
            Product(
                name: "Honeycrisp Apples",
                category: "Fruits",
                price: 4000,
                quantity: 150,
                farmLocation: "Apple Orchard",
                description: "Crisp and sweet Honeycrisp apples"
            ),
            Product(
                name: "Honeycrisp Apples",
                category: "Fruits",
                price: 4700,
                quantity: 120,
                farmLocation: "Orchard Grove",
                description: "Juicy and flavorful Honeycrisp apples"
            ),
            Product(
                name: "Sweet Potatoes",
                category: "Vegetables",
                price: 2600,
                quantity: 200,
                farmLocation: "Root Farms",
                description: "Nutritious and delicious sweet potatoes"
            ),
            Product(
                name: "Sweet Potatoes",
                category: "Vegetables",
                price: 5600,
                quantity: 220,
                farmLocation: "Harvest Hill",
                description: "Freshly harvested sweet potatoes"
            )
        ]
    }
}
