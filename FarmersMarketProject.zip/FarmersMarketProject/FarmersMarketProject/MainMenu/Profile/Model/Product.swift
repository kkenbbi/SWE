//
//  Product.swift
//  FarmersMarketProject
//
//  Created by Ариана Кенбаева on 20.11.2024.
//

import Foundation

struct Product {
    let name: String
    let category: String
    let price: Int
    let quantity: Int
    let farmLocation: String
    let description: String
}
