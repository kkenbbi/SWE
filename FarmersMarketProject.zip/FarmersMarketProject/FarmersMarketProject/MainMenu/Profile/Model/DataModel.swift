//
//  DataModel.swift
//  FarmersMarketProject
//
//  Created by Ариана Кенбаева on 19.11.2024.
//

import Foundation
struct DataModel: Codable {
    var name: String
    var description: String
    var price: Double
    var location: String
    var product: String
}

