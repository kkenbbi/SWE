//
//  GetData.swift
//  FarmersMarketProject
//
//  Created by Ариана Кенбаева on 19.11.2024.
//

import Foundation

// This class will fetch and decode your JSON data
class GetData: ObservableObject {
    @Published var data: [DataModel] = [] // Use the DataModel you created

    init() {
        load()
    }

    func load() {
        // Replace with your actual GitHub URL
        let dataUrl = URL(string: "https://raw.githubusercontent.com/nicole-jordan97/finalJSON/main/idk")!
        let decoder = JSONDecoder()

        // Use URLSession to fetch the data
        URLSession.shared.dataTask(with: dataUrl) { (data, response, error) in
            if let data = data {
                do {
                    // Decode the JSON into an array of DataModel
                    let decodedData = try decoder.decode([DataModel].self, from: data)
                    DispatchQueue.main.async {
                        self.data = decodedData
                    }
                } catch {
                    print("Error decoding JSON: \(error)")
                }
            } else {
                print("No Data")
            }
        }.resume()
        URLSession.shared.dataTask(with: dataUrl) { (data, response, error) in
                if let data = data {
                    do {
                        let decodedData = try decoder.decode([DataModel].self, from: data)
                        DispatchQueue.main.async {
                            self.data = decodedData
                            print("Loaded Data: \(self.data)") // Debugging: Check loaded data
                        }
                    } catch {
                        print("Error decoding JSON: \(error)")
                    }
                } else {
                    print("No Data")
                }
            }.resume()
    }
}

