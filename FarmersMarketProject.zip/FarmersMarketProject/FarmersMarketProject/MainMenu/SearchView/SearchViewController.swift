import UIKit

class SearchViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate {
    let searchBar = UISearchBar()
    let tableView = UITableView()
    var viewModel = SearchViewModel(productData: ProductData())

    // Define the Price Button
    let priceButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Price", for: .normal)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupSearchBar()
        setupTableView()
        setupPriceButton() // Setup the price button
        
        // Register the UITableViewCell
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        tableView.reloadData()
    }

    func setupSearchBar() {
        searchBar.delegate = self
        searchBar.placeholder = "Search here"
        searchBar.sizeToFit()
        navigationItem.titleView = searchBar
    }

    func setupTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 44
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)

        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    func setupPriceButton() {
        view.addSubview(priceButton)

        // Set up constraints for the Price button at the bottom
        NSLayoutConstraint.activate([
            priceButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            priceButton.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        ])

        // Add action to the Price button
        priceButton.addTarget(self, action: #selector(openPriceFilter), for: .touchUpInside)
    }

    @objc func openPriceFilter() {
        let priceFilterVC = PriceFilterViewController()
        priceFilterVC.onApply = { [weak self] minPrice, maxPrice in
            self?.viewModel.filterByPrice(minPrice: minPrice, maxPrice: maxPrice)
            self?.tableView.reloadData()
        }
        present(priceFilterVC, animated: true, completion: nil)
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.filteredItems.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let item = viewModel.filteredItems[indexPath.row]
        cell.textLabel?.text = "\(item.name) - Price: \(item.price)" // Display name and price together
        return cell
    }

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        viewModel.filterResults(searchText: searchText)
        tableView.reloadData()
    }
}

